DAVID STEVENSON TRUCKING — TRULOS LOAD HUNTER 4.0

INSTALL
1. Extract this ZIP to a permanent folder.
2. Chrome > chrome://extensions > Developer mode ON.
3. Remove older Load Hunter extension versions.
4. Click Load unpacked and choose the extracted Trulos_Load_Hunter_Extension folder (the folder containing manifest.json).
5. Pin the extension. Click it and choose Open Trulos Load Board.
6. Use Trulos filters to display the loads you want. Click the extension > Capture visible results.
7. Click View ranked loads. Enter route miles when available to compute $/mile and estimated profit.

IMPORTANT
This extension captures currently displayed table rows only when clicked. It does not automatically crawl Trulos or fetch its private API. Trulos Terms of Service prohibit automated harvesting without written permission. Contact Trulos for an approved feed if you want unattended refresh.

Captured data remains in Chrome local extension storage. Mileage and profit are estimates; verify rates, routes, contacts and availability with brokers. Trulos may change its page markup; this build is not verified against a live Chrome session.
