DAVID STEVENSON TRUCKING — LOAD HUNTER PRO 5.0

INSTALL
1. Extract this ZIP. Do not select the ZIP itself in Chrome.
2. Open chrome://extensions in Google Chrome.
3. Remove or disable the previous Load Hunter extension.
4. Turn on Developer mode.
5. Click Load unpacked, then select the David_Load_Hunter_5 folder containing manifest.json.
6. Pin the extension from the puzzle-piece menu.

USE
1. Click the extension and select Open Trulos Load Board.
2. Search/filter on Trulos as normal.
3. Click Capture visible listings to import recognized table rows.
4. If the table layout is not recognized, highlight a load's text and use Capture selected text, or copy/paste a listing in the popup.
5. Open Dispatch dashboard to filter, favorite, annotate, compare and rank loads.
6. Enter actual mileage and optional deadhead miles for more useful estimates.

LIMITS
- This extension does NOT independently scrape every Trulos listing, bypass restrictions, or use an authorized Trulos API. It only captures user-visible results on request.
- Trulos layout changes may break table capture. The popup reports diagnostics when nothing is recognized.
- Rates and mileage may be missing or incorrectly parsed. Verify details with the original listing and broker.
- Data is stored locally in this Chrome profile. Use Backup JSON for safekeeping.
- Estimated net is not guaranteed profit; it omits some expenses.
